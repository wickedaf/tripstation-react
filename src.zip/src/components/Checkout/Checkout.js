import React, { useEffect, useState } from 'react';
import { Container } from 'react-bootstrap';
import './Checkout.css';
import { useParams } from 'react-router-dom';
import data from '../../data/data.json';
import mapImg from '../../images/Map.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserFriends } from '@fortawesome/free-solid-svg-icons';

const Checkout = () => {
    const { tripName, locationFrom, locationTo } = useParams();
    console.log(useParams());
    const [ trip, setTrip ] = useState([]);

    useEffect(()=> {
        const tripResult = data.find(trp => trp.name === tripName);
        setTrip(tripResult);
    }, [tripName]);

    const { img, name } = trip;
   
    return (
        <Container className="checkout-container rounded">
                <div className="row g-2">
                    <div className="col-4 bg-light h-50">
                        <div className="p-3 my-3 bg-danger rounded shadow text-white">
                            <ul>
                                <li>
                                   <div className="px-3">{locationFrom}</div>
                                </li>
                                <li>
                                   <div className="px-3">{locationTo}</div>
                                </li>
                            </ul>
                        </div>
                        <div className="p-3 my-3 shadow rounded bg-white d-flex justify-content-between align-items-center">
                            <img src={img} className="w-25" alt=""/>
                            <h5>{name}</h5>
                            <p><FontAwesomeIcon icon={faUserFriends} /> 4</p>
                            <p>$67</p>
                        </div>
                        <div className="p-3 my-3 shadow rounded bg-white d-flex justify-content-between">
                            <img src={img} className="w-25" alt=""/>
                            <h5>{name}</h5>
                            <p><FontAwesomeIcon icon={faUserFriends} /> 4</p>
                            <p>$67</p>
                        </div>
                        <div className="p-3 my-3 bg-white rounded shadow d-flex justify-content-between">
                            <img src={img} className="w-25" alt=""/>
                            <h5>{name}</h5>
                            <p><FontAwesomeIcon icon={faUserFriends} /> 4</p>
                            <p>$67</p>
                        </div>
                    </div>
                    <div className="col-8">
                        <img className="shadow" src={mapImg} alt=""/>
                    </div>
                </div>
        </Container>
    );
};

export default Checkout;