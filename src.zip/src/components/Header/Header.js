import React from 'react';
import { Button, Container, Nav, Navbar } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Header = () => {
    return (
        <Container className="p-1">
            <Navbar expand="lg" >
                <Navbar.Brand href="#home"><h1>TRIPSTATION</h1></Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
                    <Nav>
                        <Nav.Link className="px-4"><Link style={{ textDecoration: 'none' }} to="/home">Home</Link></Nav.Link>
                        <Nav.Link className="px-4" ><Link style={{ textDecoration: 'none' }} to="/destination">Destination</Link></Nav.Link>
                        <Nav.Link className="px-4" href="#link">Blog</Nav.Link>
                        <Nav.Link className="px-4" href="#link">Contact</Nav.Link>
                        <Button variant="danger">Login</Button>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
            <hr/>
        </Container>
    );
};

export default Header;