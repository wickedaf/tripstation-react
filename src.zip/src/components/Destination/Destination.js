import React from 'react';
import './Destination.css';
import { Container } from 'react-bootstrap';
import { useForm } from "react-hook-form";
import mapImg from '../../images/Map.png';
import { useHistory, useParams } from 'react-router-dom';

const Destination = () => {
    const { tripName } = useParams();
    const { register, handleSubmit, watch, errors } = useForm();
    // const onSubmit = data => console.log(data);
    let history = useHistory();
    
    const onSubmit = (data) => {
        const { pickFrom, pickTo} = data;
        history.push("/checkout/"+tripName+"/"+pickFrom +"/" +pickTo);
    }
    return (
        <Container >
            <div className="row justify-content-between">
                <div className="col-4 form-container bg-light rounded shadow">
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <p>Pick From</p>
                        <input className="form-control shadow" name="pickFrom" defaultValue="Mirpur" ref={register} />
                        <br/>
                        <p>Pick To</p>
                        <input className="form-control shadow" name="pickTo" defaultValue="Dhanmondi"ref={register({ required: true })} />
                        {errors.exampleRequired && <span>This field is required</span>}
                        <br/>
                        <input className="form-control shadow bg-danger text-white"  type="submit" value="Search" />
                    </form>
                </div>
                <div className="col-8">
                    <img className="shadow" src={mapImg} alt=""/>
                </div>
            </div>    
        </Container>
    );
};

export default Destination;