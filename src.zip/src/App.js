import './App.css';
import Header from './components/Header/Header';
import Home from './components/Home/Home';
import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";
import Destination from './components/Destination/Destination';
import Checkout from './components/Checkout/Checkout';

function App() {
  return (
    <div>
      <Router>
        <Header></Header>
        <Switch>
          <Route path="/home">
            <Home></Home>
          </Route>
          <Route path="/trip-type/:tripName">
            <Destination></Destination>
          </Route>
          <Route path="/checkout/:tripName/:locationFrom/:locationTo">
            <Checkout></Checkout>
          </Route>
          <Route path="/">
            <Home />
          </Route>
        </Switch>
      </Router>
    </div>
  );
}

export default App;
